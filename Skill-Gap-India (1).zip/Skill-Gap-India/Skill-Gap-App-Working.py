# Databricks notebook source
# DBTITLE 1,Load Data & Setup


import pandas as pd
import plotly.express as px

# Load recommendations data
df = spark.table("workspace.default.final_recommendations").toPandas()

# Clean skill names
df['skill_display'] = df['skill'].str.replace('Skill_', '', regex=False)

# Add priority levels
def get_priority(gap):
    if gap > 70:
        return '🔴 CRITICAL', '#f44336'
    elif gap > 40:
        return '🟡 MODERATE', '#ff9800'
    else:
        return '🟢 LOW', '#4caf50'

df[['priority', 'color']] = df['gap_score'].apply(lambda x: pd.Series(get_priority(x)))

# Sort by gap score descending
df = df.sort_values('gap_score', ascending=False).reset_index(drop=True)

print(f"✅ Loaded {len(df)} skills")
print(f"🔴 Critical: {len(df[df['gap_score'] > 70])}")
print(f"🟡 Moderate: {len(df[(df['gap_score'] > 40) & (df['gap_score'] <= 70)])}")
print(f"🟢 Low: {len(df[df['gap_score'] <= 40])}")

# COMMAND ----------

# DBTITLE 1,Skill Selection Widget
# Create dropdown with all skills
skill_options = df['skill_display'].tolist()
dbutils.widgets.dropdown("selected_skill", skill_options[0], skill_options, "📚 Select Skill Area")

print("✅ Widget created! Select a skill from the dropdown above.")

# COMMAND ----------

# DBTITLE 1,Display Selected Skill Details
# Get selected skill
selected = dbutils.widgets.get("selected_skill")
row = df[df['skill_display'] == selected].iloc[0]

gap = row['gap_score']
avg = row['avg_score']
course = row['recommended_course']
priority = row['priority']
color = row['color']

# Beautiful HTML card
html = f"""
<div style="font-family: 'Arial', sans-serif; max-width: 800px; margin: 20px auto;">
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 15px 15px 0 0; text-align: center; color: white;">
        <h1 style="margin: 0; font-size: 2.5em;">🎓 {selected}</h1>
    </div>
    
    <!-- Gap Score Card -->
    <div style="background: white; padding: 30px; border-left: 5px solid {color}; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <h2 style="color: #333; margin-top: 0;">📊 Industry Gap Score</h2>
        <div style="background: #f5f5f5; border-radius: 10px; height: 40px; position: relative; overflow: hidden; margin: 20px 0;">
            <div style="background: {color}; height: 100%; width: {gap}%; border-radius: 10px; transition: width 0.3s;"></div>
            <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-weight: bold; font-size: 1.2em; color: #333;">{gap:.1f}%</span>
        </div>
        
        <div style="display: flex; justify-content: space-between; margin: 30px 0;">
            <div style="text-align: center; flex: 1;">
                <div style="font-size: 0.9em; color: #666; margin-bottom: 5px;">Priority Level</div>
                <div style="font-size: 1.5em; color: {color}; font-weight: bold;">{priority}</div>
            </div>
            <div style="text-align: center; flex: 1; border-left: 2px solid #eee; border-right: 2px solid #eee;">
                <div style="font-size: 0.9em; color: #666; margin-bottom: 5px;">Average Score</div>
                <div style="font-size: 1.5em; color: #1976D2; font-weight: bold;">{avg:.2f}</div>
            </div>
            <div style="text-align: center; flex: 1;">
                <div style="font-size: 0.9em; color: #666; margin-bottom: 5px;">Rank</div>
                <div style="font-size: 1.5em; color: #1976D2; font-weight: bold;">#{df[df['skill_display']==selected].index[0] + 1}</div>
            </div>
        </div>
    </div>
    
    <!-- Course Recommendation -->
    <div style="background: #e3f2fd; padding: 25px; border-radius: 0 0 15px 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <h2 style="color: #1976D2; margin-top: 0;">✅ Recommended Free Course</h2>
        <div style="background: white; padding: 20px; border-radius: 10px; border-left: 4px solid #1976D2;">
            <div style="font-size: 1.3em; font-weight: bold; color: #333; margin-bottom: 10px;">{course}</div>
            <a href="https://swayam.gov.in" target="_blank" style="display: inline-block; background: #1976D2; color: white; padding: 12px 30px; text-decoration: none; border-radius: 25px; font-weight: bold; margin-top: 10px;">🔗 Access Free on SWAYAM</a>
            <div style="margin-top: 15px; font-size: 0.9em; color: #666;">💡 SWAYAM offers free online courses from top Indian universities</div>
        </div>
    </div>
</div>
"""

displayHTML(html)

# COMMAND ----------

# DBTITLE 1,Gap Score Visualization
# Create interactive bar chart
fig = px.bar(
    df,
    x='skill_display',
    y='gap_score',
    color='gap_score',
    color_continuous_scale=['#4caf50', '#ff9800', '#f44336'],
    title='<b>🇮🇳 Skill Gap India - Industry Demand Analysis</b>',
    labels={'skill_display': 'Skill Area', 'gap_score': 'Gap Score (%)'},
    text='gap_score',
    height=500
)

fig.update_traces(
    texttemplate='%{text:.1f}%',
    textposition='outside',
    hovertemplate='<b>%{x}</b><br>Gap Score: %{y:.1f}%<extra></extra>'
)

fig.update_layout(
    xaxis_tickangle=-45,
    showlegend=False,
    xaxis_title="<b>Skill Area</b>",
    yaxis_title="<b>Gap Score (%)</b>",
    yaxis_range=[0, 110],
    font=dict(size=12),
    title_font_size=20,
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
    margin=dict(t=100, b=100)
)

fig.add_hline(y=70, line_dash="dash", line_color="red", annotation_text="Critical Threshold", annotation_position="right")
fig.add_hline(y=40, line_dash="dash", line_color="orange", annotation_text="Moderate Threshold", annotation_position="right")

display(fig)

# COMMAND ----------

# DBTITLE 1,Complete Skills Table
# Prepare display table
display_df = df[['skill_display', 'gap_score', 'priority', 'avg_score', 'recommended_course']].copy()
display_df.columns = ['🎯 Skill Area', '📊 Gap Score (%)', '🚨 Priority', '📈 Avg Score', '✅ Recommended Course']
display_df['📊 Gap Score (%)'] = display_df['📊 Gap Score (%)'].round(1)
display_df['📈 Avg Score'] = display_df['📈 Avg Score'].round(2)

print("="*80)
print("📋 COMPLETE SKILL GAP RANKINGS - INDIA".center(80))
print("="*80)
print()

display(display_df)

print()
print("📌 Key Insights:")
print(f"   🔴 Highest Gap: {df.iloc[0]['skill_display']} ({df.iloc[0]['gap_score']:.1f}%)")
print(f"   🟢 Lowest Gap: {df.iloc[-1]['skill_display']} ({df.iloc[-1]['gap_score']:.1f}%)")
print(f"   ⚠️  Critical Skills: {len(df[df['gap_score'] > 70])} areas need urgent attention")
print(f"   📚 Total Free Courses Available: {len(df)}")
print()
print("🔗 All courses available at: https://swayam.gov.in")