# Databricks notebook source
# MAGIC %pip install faiss-cpu sentence-transformers

# COMMAND ----------

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# SWAYAM Courses
swayam_courses = [
    {"course": "Python Programming - IIT Madras", "skill": "Programming"},
    {"course": "Cloud Computing - IIT Kharagpur", "skill": "Cloud"},
    {"course": "DevOps Fundamentals - NPTEL", "skill": "DevOps"},
    {"course": "Cyber Security - IIT Bombay", "skill": "CyberSec"},
    {"course": "Mobile App Development - NPTEL", "skill": "MobileDev"},
    {"course": "Data Analysis with Python - IIT Madras", "skill": "DataAnalysis"},
    {"course": "IoT Foundation - IIT Kharagpur", "skill": "IoT"},
    {"course": "Machine Learning - IIT Bombay", "skill": "ML_AI"},
    {"course": "Web Development - NPTEL", "skill": "WebDev"},
]

# Encode courses
model = SentenceTransformer('all-MiniLM-L6-v2')
course_texts = [c["skill"] for c in swayam_courses]
embeddings = model.encode(course_texts)

# Build FAISS index
index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(np.array(embeddings))

# Recommend function
def recommend(skill):
    vec = model.encode([skill])
    _, idx = index.search(np.array(vec), k=1)
    return swayam_courses[idx[0][0]]["course"]

# Test
print(recommend("Programming"))
print(recommend("Cloud"))
print(recommend("DevOps"))
print("FAISS Recommender Ready ✅")

# COMMAND ----------

# Combine Gap Scores + Course Recommendations
gap_data = spark.table("gold_skill_gaps").toPandas()
gap_data["recommended_course"] = gap_data["skill"].apply(
    lambda x: recommend(x.replace("Skill_", ""))
)

# Save final output
spark.createDataFrame(gap_data) \
    .write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("final_recommendations")

display(spark.table("final_recommendations"))
print("Final output ready ✅")

# COMMAND ----------

# Add this as a new cell in 02_faiss_recommender

dbutils.widgets.text("Enter Your Subject", "Mathematics")
subject = dbutils.widgets.get("Enter Your Subject")

# Map subject to skill
subject_skill_map = {
    "Mathematics": "Skill_Programming",
    "Programming": "Skill_Programming",
    "Networks": "Skill_Cloud",
    "Web Development": "Skill_WebDev",
    "Machine Learning": "Skill_ML_AI",
    "Mobile Development": "Skill_MobileDev",
    "Data Analysis": "Skill_DataAnalysis",
    "Cyber Security": "Skill_CyberSec",
    "DevOps": "Skill_DevOps",
}

matched_skill = subject_skill_map.get(subject, "Skill_Programming")
filtered_gap = gap_data[gap_data['skill'] == matched_skill]

if len(filtered_gap) == 0:
    print(f"❌ Skill '{matched_skill}' not found in gap analysis data.")
    print(f"Available skills: {', '.join(gap_data['skill'].tolist())}")
else:
    gap = filtered_gap['gap_score'].values[0]
    course = recommend(matched_skill.replace("Skill_", ""))

    print(f"📚 Subject: {subject}")
    print(f"📊 Industry Gap Score: {gap:.1f}%")
    print(f"🚨 Priority: {'CRITICAL' if gap > 70 else 'MODERATE' if gap > 40 else 'LOW'}")
    print(f"✅ Recommended Free Course: {course}")
    print(f"🔗 Access it free at: https://swayam.gov.in")