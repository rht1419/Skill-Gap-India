import streamlit as st
import pandas as pd
import plotly.express as px
from databricks.sdk import WorkspaceClient
from databricks.sdk.runtime import *

# Page configuration
st.set_page_config(
    page_title="Skill Gap India - Course Recommender",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        color: #1E88E5;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin: 1rem 0;
    }
    .critical { color: #f44336; font-weight: bold; }
    .moderate { color: #ff9800; font-weight: bold; }
    .low { color: #4caf50; font-weight: bold; }
    </style>
""", unsafe_allow_html=True)

# Initialize Databricks client
@st.cache_resource
def get_databricks_client():
    """Initialize Databricks Workspace Client with authentication"""
    try:
        # For Databricks Apps, authentication is handled automatically
        w = WorkspaceClient()
        return w
    except Exception as e:
        st.error(f"Failed to connect to Databricks: {e}")
        return None

# Load data from Delta table
@st.cache_data(ttl=600)  # Cache for 10 minutes
def load_recommendations():
    """Load skill gap recommendations from Delta table"""
    try:
        # Use Spark to read Delta table directly
        df = spark.table("workspace.default.final_recommendations")
        pdf = df.toPandas()
        
        # Clean skill names (remove 'Skill_' prefix for display)
        pdf['skill_display'] = pdf['skill'].str.replace('Skill_', '', regex=False)
        
        # Sort by gap score descending
        pdf = pdf.sort_values('gap_score', ascending=False).reset_index(drop=True)
        
        return pdf
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

def get_priority_level(gap_score):
    """Determine priority level based on gap score"""
    if gap_score > 70:
        return "🔴 CRITICAL", "critical"
    elif gap_score > 40:
        return "🟡 MODERATE", "moderate"
    else:
        return "🟢 LOW", "low"

def main():
    # Header
    st.markdown('<h1 class="main-header">📚 Skill Gap India - Course Recommender</h1>', unsafe_allow_html=True)
    st.markdown("### 🎯 Identify skill gaps and discover free courses to bridge them")
    st.markdown("---")
    
    # Load data
    with st.spinner('Loading skill gap analysis...'):
        data = load_recommendations()
    
    if data is None or data.empty:
        st.warning("No data available. Please ensure the final_recommendations table contains data.")
        return
    
    # Sidebar - Skill Selection
    st.sidebar.image("https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Flag_of_India.svg/320px-Flag_of_India.svg.png", width=100)
    st.sidebar.title("🔍 Skill Selection")
    st.sidebar.markdown("Select a skill area to view detailed recommendations:")
    
    selected_skill_display = st.sidebar.selectbox(
        "Choose Skill Area:",
        options=data['skill_display'].tolist(),
        index=0
    )
    
    # Get selected skill data
    selected_row = data[data['skill_display'] == selected_skill_display].iloc[0]
    gap_score = selected_row['gap_score']
    avg_score = selected_row['avg_score']
    recommended_course = selected_row['recommended_course']
    priority_label, priority_class = get_priority_level(gap_score)
    
    # Main content area - 2 columns
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Skill Details Card
        st.markdown(f"### 🎓 Skill: **{selected_skill_display}**")
        
        # Gap Score with Progress Bar
        st.markdown("#### 📊 Industry Gap Score")
        st.progress(gap_score / 100)
        st.markdown(f"<h2 style='text-align: center;'>{gap_score:.1f}%</h2>", unsafe_allow_html=True)
        
        # Priority Level
        st.markdown(f"#### 🚨 Priority Level")
        st.markdown(f"<p class='{priority_class}' style='font-size: 1.5rem; text-align: center;'>{priority_label}</p>", unsafe_allow_html=True)
        
    with col2:
        # Metrics
        st.metric(
            label="📈 Average Skill Score",
            value=f"{avg_score:.2f}",
            delta="Industry Average"
        )
        
        # Recommended Course
        st.markdown("#### ✅ Recommended Free Course")
        st.info(f"**{recommended_course}**")
        st.markdown(f"[🔗 Access Free on SWAYAM](https://swayam.gov.in)")
        st.markdown("*SWAYAM offers free online courses from top Indian universities*")
    
    st.markdown("---")
    
    # Visualization Section
    tab1, tab2 = st.tabs(["📊 Gap Score Visualization", "📋 All Skills Table"])
    
    with tab1:
        st.markdown("### 📊 Skill Gap Scores Across All Areas")
        
        # Create bar chart using Plotly
        fig = px.bar(
            data,
            x='skill_display',
            y='gap_score',
            color='gap_score',
            color_continuous_scale=['#4caf50', '#ff9800', '#f44336'],
            labels={'skill_display': 'Skill Area', 'gap_score': 'Gap Score (%)'},
            title='Skill Gap Analysis - Industry Demand vs Current Supply',
            text='gap_score'
        )
        
        fig.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
        fig.update_layout(
            xaxis_tickangle=-45,
            height=500,
            showlegend=False,
            xaxis_title="Skill Area",
            yaxis_title="Gap Score (%)",
            yaxis_range=[0, 105]
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Key Insights
        st.markdown("#### 💡 Key Insights")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            top_gap = data.iloc[0]
            st.markdown(f"**🔴 Highest Gap:**")
            st.markdown(f"{top_gap['skill_display']} ({top_gap['gap_score']:.1f}%)")
        
        with col2:
            critical_count = len(data[data['gap_score'] > 70])
            st.markdown(f"**⚠️ Critical Skills:**")
            st.markdown(f"{critical_count} areas need urgent attention")
        
        with col3:
            lowest_gap = data.iloc[-1]
            st.markdown(f"**🟢 Lowest Gap:**")
            st.markdown(f"{lowest_gap['skill_display']} ({lowest_gap['gap_score']:.1f}%)")
    
    with tab2:
        st.markdown("### 📋 Complete Skill Gap Rankings")
        
        # Prepare display dataframe
        display_df = data[['skill_display', 'gap_score', 'avg_score', 'recommended_course']].copy()
        display_df.columns = ['Skill Area', 'Gap Score (%)', 'Avg Score', 'Recommended Course']
        display_df['Gap Score (%)'] = display_df['Gap Score (%)'].round(1)
        display_df['Avg Score'] = display_df['Avg Score'].round(2)
        display_df['Priority'] = display_df['Gap Score (%)'].apply(lambda x: get_priority_level(x)[0])
        
        # Reorder columns
        display_df = display_df[['Skill Area', 'Gap Score (%)', 'Priority', 'Avg Score', 'Recommended Course']]
        
        # Display table with conditional formatting
        st.dataframe(
            display_df,
            use_container_width=True,
            height=400,
            hide_index=True
        )
        
        # Download button
        csv = display_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Complete Report (CSV)",
            data=csv,
            file_name="skill_gap_india_report.csv",
            mime="text/csv"
        )
    
    # Footer
    st.markdown("---")
    st.markdown("""
        <div style='text-align: center; color: #666; padding: 2rem;'>
            <p><strong>Skill Gap India Initiative</strong></p>
            <p>Helping bridge the skills gap through accessible education</p>
            <p>Data sourced from industry analysis | Courses from SWAYAM platform</p>
        </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
