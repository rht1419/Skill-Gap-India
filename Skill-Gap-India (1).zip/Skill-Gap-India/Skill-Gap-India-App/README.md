# 📚 Skill Gap India - Course Recommender App

A Databricks-powered Streamlit application that analyzes skill gaps in the Indian workforce and recommends free SWAYAM courses to bridge them.

## 🎯 Features

* **Interactive Skill Selection**: Dropdown menu to explore different skill areas
* **Gap Score Visualization**: Progress bars and charts showing industry demand gaps
* **Priority Levels**: Color-coded priorities (🔴 CRITICAL >70%, 🟡 MODERATE 40-70%, 🟢 LOW <40%)
* **Course Recommendations**: Free SWAYAM courses mapped to each skill gap
* **Comprehensive Dashboard**: 
  * Bar chart showing all skill gaps
  * Sortable table with complete rankings
  * Key insights and statistics
  * CSV export functionality
* **Modern UI**: Clean design with emojis and responsive layout

## 🏗️ Architecture

```
Databricks Workspace
└── Delta Tables
    └── workspace.default.final_recommendations
        ├── skill (string)
        ├── avg_score (double)
        ├── gap_score (double)
        └── recommended_course (string)

Streamlit App
├── app.py (main application)
├── requirements.txt (dependencies)
└── app.yml (Databricks Apps config)
```

## 📋 Prerequisites

1. Databricks workspace on AWS
2. Delta table `workspace.default.final_recommendations` with data
3. SQL Warehouse or Serverless compute
4. Databricks Apps enabled on your workspace

## 🚀 Deployment Instructions

### Option 1: Deploy as Databricks App (Recommended)

1. **Navigate to Apps** in your Databricks workspace sidebar

2. **Create New App**:
   * Click "Create App"
   * Name: "Skill Gap India"
   * Select the folder: `/Users/nandanathreya26@gmail.com/Skill-Gap-India-App`

3. **Configure Resources**:
   * The app will automatically use your workspace's default SQL warehouse
   * Serverless compute will be used for data access

4. **Deploy**:
   * Click "Deploy"
   * Wait for the app to start (usually 2-3 minutes)
   * Access via the generated URL

### Option 2: Run Locally (Development)

```bash
# Install dependencies
pip install -r requirements.txt

# Set Databricks environment variables
export DATABRICKS_HOST="https://your-workspace.cloud.databricks.com"
export DATABRICKS_TOKEN="your-token"

# Run the app
streamlit run app.py
```

## 📊 Data Requirements

The app expects a Delta table with the following schema:

```sql
CREATE TABLE workspace.default.final_recommendations (
  skill STRING,
  avg_score DOUBLE,
  gap_score DOUBLE,
  recommended_course STRING
);
```

**Sample Data**:
```sql
INSERT INTO workspace.default.final_recommendations VALUES
  ('Skill_Programming', 1.93, 100.0, 'Python Programming - IIT Madras'),
  ('Skill_DataAnalysis', 0.02, 62.97, 'Data Analytics - NPTEL'),
  ('Skill_ML_AI', -0.48, 53.18, 'Machine Learning - IIT Kharagpur');
```

## 🎨 User Interface

### Main Dashboard
* **Header**: Title with branding
* **Sidebar**: Skill selection dropdown with Indian flag
* **Main Panel**:
  * Left: Selected skill details with progress bar
  * Right: Metrics and course recommendation
* **Tabs**:
  * Visualization: Interactive bar chart
  * Table: Full rankings with download option

### Color Coding
* 🔴 **CRITICAL** (>70%): Red - Urgent attention needed
* 🟡 **MODERATE** (40-70%): Orange - Significant gap
* 🟢 **LOW** (<40%): Green - Manageable gap

## 🔧 Configuration

### app.yml
* Defines the Streamlit command and port (8080)
* Configures SQL warehouse access
* Sets up permissions

### requirements.txt
* `streamlit>=1.28.0`: Web app framework
* `databricks-sdk>=0.12.0`: Databricks API access
* `pandas>=2.0.0`: Data manipulation
* `plotly>=5.17.0`: Interactive visualizations

## 📈 Usage Examples

### View Programming Skill Gap
1. Select "Programming" from dropdown
2. See gap score of 100% (critical)
3. View recommended course: "Python Programming - IIT Madras"
4. Click SWAYAM link to access course

### Analyze All Skills
1. Navigate to "📊 Gap Score Visualization" tab
2. View bar chart ranked by gap severity
3. Identify top 3 critical skills

### Export Report
1. Go to "📋 All Skills Table" tab
2. Review complete rankings
3. Click "📥 Download Complete Report (CSV)"
4. Use data for presentations or planning

## 🔐 Security Notes

* App uses workspace authentication (no credentials in code)
* Data access controlled by Unity Catalog permissions
* App inherits user's table access rights

## 🐛 Troubleshooting

**Issue**: "No data available" error
* **Solution**: Verify `final_recommendations` table exists and has data
* Check table name: `workspace.default.final_recommendations`
* Run: `SELECT * FROM workspace.default.final_recommendations LIMIT 10`

**Issue**: Import errors
* **Solution**: Ensure all dependencies in requirements.txt are installed
* Redeploy the app to refresh packages

**Issue**: "Failed to connect to Databricks"
* **Solution**: Verify SQL warehouse is running
* Check app permissions in Databricks workspace

## 📝 Future Enhancements

* [ ] Add filtering by priority level
* [ ] Include historical trend analysis
* [ ] Add user skill assessment integration
* [ ] Multi-language support (Hindi, Tamil, etc.)
* [ ] Email/notification for new course recommendations
* [ ] Integration with LinkedIn Learning, Coursera

## 📧 Support

For issues or questions:
1. Check the troubleshooting section
2. Review Databricks Apps documentation
3. Contact workspace administrator

## 📄 License

This project is part of the Skill Gap India initiative to promote accessible education.

---

**Built with ❤️ using Databricks & Streamlit**
