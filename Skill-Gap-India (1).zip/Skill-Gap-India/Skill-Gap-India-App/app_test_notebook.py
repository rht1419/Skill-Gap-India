# Databricks notebook source
# DBTITLE 1,Load data from final_recommendations table
# Test Cell 1: Load and display data from Delta table
import pandas as pd

# Load data from Delta table
df = spark.table("workspace.default.final_recommendations")
pdf = df.toPandas()

print(f"✅ Loaded {len(pdf)} skills from final_recommendations table")
print(f"\nColumns: {pdf.columns.tolist()}")
print(f"\nFirst 5 rows:")
display(pdf.head())

# Check data types
print(f"\nData types:")
print(pdf.dtypes)

# COMMAND ----------

# DBTITLE 1,Test data transformation logic
# Test Cell 2: Data transformation (app logic)

# Clean skill names (remove 'Skill_' prefix)
pdf['skill_display'] = pdf['skill'].str.replace('Skill_', '', regex=False)

# Sort by gap score descending
pdf_sorted = pdf.sort_values('gap_score', ascending=False).reset_index(drop=True)

print("✅ Data transformation complete")
print(f"\nTop 5 skills by gap score:")
display(pdf_sorted[['skill_display', 'gap_score', 'recommended_course']].head())

print(f"\nBottom 3 skills by gap score:")
display(pdf_sorted[['skill_display', 'gap_score', 'recommended_course']].tail(3))

# COMMAND ----------

# DBTITLE 1,Create plotly bar chart
# Test Cell 3: Create plotly bar chart visualization
import plotly.express as px

# Create bar chart
fig = px.bar(
    pdf_sorted,
    x='skill_display',
    y='gap_score',
    color='gap_score',
    color_continuous_scale=['#4caf50', '#ff9800', '#f44336'],
    labels={'skill_display': 'Skill Area', 'gap_score': 'Gap Score (%)'},
    title='📊 Skill Gap Analysis - Industry Demand vs Current Supply',
    text='gap_score'
)

fig.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
fig.update_layout(
    xaxis_tickangle=-45,
    height=500,
    showlegend=False,
    xaxis_title="Skill Area",
    yaxis_title="Gap Score (%)",
    yaxis_range=[0, 105]
)

print("✅ Chart created successfully")
fig.show()

# COMMAND ----------

# DBTITLE 1,Display formatted table with priorities
# Test Cell 4: Display formatted table with priority levels

def get_priority_level(gap_score):
    """Determine priority level based on gap score"""
    if gap_score > 70:
        return "🔴 CRITICAL"
    elif gap_score > 40:
        return "🟡 MODERATE"
    else:
        return "🟢 LOW"

# Create display dataframe
display_df = pdf_sorted[['skill_display', 'gap_score', 'avg_score', 'recommended_course']].copy()
display_df.columns = ['Skill Area', 'Gap Score (%)', 'Avg Score', 'Recommended Course']
display_df['Gap Score (%)'] = display_df['Gap Score (%)'].round(1)
display_df['Avg Score'] = display_df['Avg Score'].round(2)
display_df['Priority'] = display_df['Gap Score (%)'].apply(get_priority_level)

# Reorder columns
display_df = display_df[['Skill Area', 'Gap Score (%)', 'Priority', 'Avg Score', 'Recommended Course']]

print("✅ Formatted table with priorities:")
print(f"\n{'='*100}")
display(display_df)
print(f"{'='*100}")

# Key insights
print(f"\n💡 Key Insights:")
print(f"  🔴 Highest Gap: {display_df.iloc[0]['Skill Area']} ({display_df.iloc[0]['Gap Score (%)']}%)")
critical_count = len(display_df[display_df['Gap Score (%)'] > 70])
print(f"  ⚠️ Critical Skills: {critical_count} areas need urgent attention")
print(f"  🟢 Lowest Gap: {display_df.iloc[-1]['Skill Area']} ({display_df.iloc[-1]['Gap Score (%)']}%)")
print(f"\n✅ All app logic validated successfully!")